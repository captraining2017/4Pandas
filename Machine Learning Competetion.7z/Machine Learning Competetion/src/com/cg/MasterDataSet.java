package com.cg;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

public class MasterDataSet {
	
	LinkedHashMap<Integer, Integer> getMasterdate() throws IOException
	{
		FileWriter fileWriter2 = new FileWriter(new File("C:\\WorkSpace\\RC_PLUS\\Machine Learning Competetion\\MasterDataDetails"));
		fileWriter2.write("Customer ID" + "\t\t\t" + "Customer Salary\n");
		
		
		LinkedHashMap<Integer, Integer> linkedHashMap=new LinkedHashMap<Integer, Integer>();
		//System.out.println("________________________________________________________");
		//System.out.println("Customer ID" + "\t\t\t" + "Customer Salary");
		//System.out.println("________________________________________________________|");
		//System.out.println("\t\t" + "Low Salary");
		fileWriter2.write("\t\t" + "Low Salary\n");
		//System.out.println("________________________________________________________|");
		// for loop to generate Low salary for 30% of Customer
		for (int i = 2546001; i <= 2546030; i++) {
			Random random = new Random();
			int LowSal = random.nextInt(500000 - 120000) + 120000;
			fileWriter2.write((i) + "\t\t\t\t" + LowSal + "\t\t\t\n");
			//System.out.println((i) + "\t\t|\t\t" + LowSal + "\t\t\t|");
			linkedHashMap.put(i, (LowSal/12));
		}
		//System.out.println("____________________________________________________");
		fileWriter2.write("\t\t" + "medium Salary\n");
		//System.out.println("\t\t" + "medium Salary");
		//System.out.println("____________________________________________________");
		// for loop to generate Medium salary for 40% of Customer
		for (int j = 2546031; j <= 2546070; j++) {
			Random random = new Random();
			int MedSal = random.nextInt(1000000 - 510000) + 510000;
			fileWriter2.write((j) + "\t\t\t\t" + MedSal + "\t\t\t\n");
			//System.out.println((j) + "\t\t|\t\t" + MedSal + "\t\t\t|");
			linkedHashMap.put(j, (MedSal/12));
		}
		//System.out.println("_____________________________________________________");
		fileWriter2.write("\t\t" + "High Salary\n");
		//System.out.println("\t\t" + "High Salary");
		//System.out.println("_____________________________________________________");
		// for loop to generate High salary for 30% of Customer
		for (int k = 2546071; k <= 2546100; k++) {
			Random random = new Random();
			int HighSal = random.nextInt(2000000 - 1010000) + 1010000;
			fileWriter2.write((k) + "\t\t\t\t" + HighSal + "\t\t\t\n");
			//System.out.println((k) + "\t\t|\t\t" + HighSal + "\t\t\t|");
			linkedHashMap.put(k, (HighSal/12));
		}
		/*for(Map.Entry m:linkedHashMap.entrySet())
		{
			System.out.println(m.getKey()+"   "+m.getValue());
		}*/
		
		fileWriter2.close();
	
		return linkedHashMap;
		}		

	}