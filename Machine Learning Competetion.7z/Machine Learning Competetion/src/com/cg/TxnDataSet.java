package com.cg;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
//import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
//import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
//import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

import com.sun.xml.internal.bind.v2.runtime.unmarshaller.XsiNilLoader.Array;
//import java.util.Set;

public class TxnDataSet {

	public static void main(String[] args) throws ParseException, IOException {
		
		//File file = new File("C:\\WorkSpace\\RC_PLUS\\Machine Learning Competetion\\txnDataDetails");
		FileWriter fileWriter = new FileWriter(new File("C:\\WorkSpace\\RC_PLUS\\Machine Learning Competetion\\txnDataDetails"));
		
		MasterDataSet masterData = new MasterDataSet();
		Map<Integer, Integer> masterdateSet =	masterData.getMasterdate();
		
		//System.out.println("master Data Set \n"+masterdateSet.toString());
		//System.out.println(masterdateSet.size());
		//System.out.println(masterdateSet.get(2546001));
	
		//Object [] masterCustomerData = new Object[2];
		Random randomGenerator = new Random();
				
		Calendar calendar = new GregorianCalendar(2016,0,10);
		int noOfDayInMOnth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		//System.out.println(calendar.get(Calendar.MONTH)+"-"+calendar.get(Calendar.YEAR));
		//System.out.println(noOfDayInMOnth);
		
		Set<Integer> keysss = masterdateSet.keySet();
		/*for(Integer keyss : keysss)
		{
			System.out.println(masterdateSet.get(keyss));
		}
		
*/		
		
		
		//for(int customerIndex=1;customerIndex<masterdateSet.size();customerIndex++)
		Map<Integer, ArrayList<Object>> overAllData = new LinkedHashMap<>();
		for(Integer keyss: keysss)
		{	
			long customerSalary = masterdateSet.get(keyss);
			Integer customerID = keyss;//masterdateSet.get(keyss);
			//System.out.println(customerID+" "+customerSalary);
			long totalAmount = 0;
			long totalCreditAmount=0;
			
			ArrayList<Object> allTxnDetails = new ArrayList<Object>();
			for(int monthIndex=0;monthIndex<=14;monthIndex++)//15 indicate the 15 month i.e from 01-JAN-2016 to 31-MAR-2017
			{			 
					 calendar = getCalender(monthIndex);//new GregorianCalendar(2016,monthIndex,01);

					 noOfDayInMOnth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
					 int currentMonth =1 + calendar.get(Calendar.MONTH);
					 int currentYear = calendar.get(Calendar.YEAR);
					 int totalTxnPerMonth = randomGenerator.nextInt(25-20)+20;
					 int remainingTxnPerMonth = totalTxnPerMonth-1;
					 //System.out.println(totalTxnPerMonth+" : "+remainingTxnPerMonth);
					 
					 totalAmount = totalAmount+customerSalary;
					 totalCreditAmount = totalCreditAmount + customerSalary;
					 allTxnDetails.add(new Master("01/"+currentMonth+"/"+currentYear, customerID, customerSalary, "Cr", totalAmount,totalCreditAmount));//every month salary
					 
					 int temp1 = randomGenerator.nextInt(remainingTxnPerMonth-1)+1;
					 int temp2 = remainingTxnPerMonth-temp1;
					 int creditDate,debitDate;
					 //System.out.println(temp1+" : "+temp2);
					
					 ArrayList<Integer> list = new ArrayList<Integer>();
					 //System.out.println(list.toString());
					 
					 ArrayList<Integer> selectedDates = new ArrayList<Integer>();
					 for(int i=1;i<=noOfDayInMOnth;i++)
					 {
						 list.add(new Integer(i));
					 }
					 //System.out.println("Before shfulling \n"+list);
					 Collections.shuffle(list);
					 //System.out.println("After shfulling \n"+list);
					 
					 for(int i=0;i<remainingTxnPerMonth;i++)
					 {
						 selectedDates.add(list.get(i));
					 }
					
					 //System.out.println("selected dates : \n"+selectedDates.toString());
					 
					 if(temp1<=temp2)
						 {
						 creditDate = temp1/2;
					 	 debitDate = temp2;
					 	 }
					 else 
						 {
						 creditDate = temp2/2;
					 	 debitDate = temp1;
					 	 }
					 	 
					 Object[] creditDateArray = new Object[creditDate];
					// Object[] debitDateArray = new Object[debitDate];
					 
					 for(int i=0;i<creditDateArray.length;i++)
					 {
						 creditDateArray[i] = selectedDates.get(i);
					 }

					Collections.sort(selectedDates);
					//System.out.println("Dates in ascending order : \n"+selectedDates);
					
					for(Object qq : selectedDates)
					{
						boolean foundFlag = false;
						long txnAmt = 0;
						//System.out.println("qq : "+qq);
						for(int i=0;i<creditDateArray.length;i++)
						{
							if(qq.equals(creditDateArray[i]))//credit happens here
							{
								foundFlag = true;
								//System.out.println("yes credit date found : "+qq);
								if(customerSalary*12<500000)
								{
									txnAmt = randomGenerator.nextInt(20000-500)+500;
								}
								else if(customerSalary*12<1000000 && customerSalary*12>500000)
								{
									txnAmt = randomGenerator.nextInt(30000-500)+500;
								}
								else
								{
									txnAmt = randomGenerator.nextInt(40000-500)+500;
								}
								
								txnAmt = txnAmt- (txnAmt%100);
								totalAmount = totalAmount+txnAmt; 
								totalCreditAmount = totalCreditAmount+txnAmt;
								allTxnDetails.add(new Master(qq.toString()+"/"+currentMonth+"/"+currentYear, customerID, txnAmt, "Cr", totalAmount,totalCreditAmount));
								break;
							}
						}
						
						
						if(!foundFlag)//debit happend here
						{
							int possibleDebit =  (int) (totalAmount/4);
							//System.out.println((possibleDebit-100)+100);
							if((possibleDebit-100)+100<=100)
							{
								txnAmt = 0;
							}
							else
							{
							txnAmt = randomGenerator.nextInt(possibleDebit-100)+100;}
							totalAmount = totalAmount - txnAmt;
							allTxnDetails.add(new Master(qq.toString()+"/"+currentMonth+"/"+currentYear, customerID, txnAmt, "Dr", totalAmount,totalCreditAmount));
						}							
					}					
				}
			//System.out.println(allTxnDetails.toString());
			overAllData.put(customerID, allTxnDetails);
			}
		//System.out.println("OverAllData \n"+overAllData);
		fileWriter.write("Customer ID,Transaction Date,Transaction Amount,Transaction Type\n");
		
		//System.out.println("Customer ID \t\t Transaction Date \t\t Transaction Amount \t\t Transaction Type \t\t Total Amount \t\t Total Credit Amount ");
		
		for(Integer keyss: keysss)
		{
			ArrayList<Object> mas = overAllData.get(keyss);
			for(Object eachObject : mas)
			{
				Master masss = (Master) eachObject;
				//fileWriter.write(masss.getCustomeID()+"\t\t\t\t\t"+masss.getDate()+"\t\t\t\t\t"+masss.getTxnAmount()+"\t\t\t\t\t\t"+masss.getTxnType()+"\t\t\t\t\t\t"+masss.getTotalAmount()+"\n");
				fileWriter.write(masss.getCustomeID()+","+masss.getDate()+","+masss.getTxnAmount()+","+masss.getTxnType()+"\n");
				//System.out.println(masss.getCustomeID()+"\t\t"+masss.getDate()+"\t\t"+masss.getTxnAmount()+"\t\t"+masss.getTxnType()+"\t\t"+masss.getTotalAmount());
			}
			//System.out.println(overAllData.get(keysss));
		}
		
		fileWriter.close();		
	}



	public static Calendar getCalender(int monthIndex)
	{
		Calendar calendar = null;
		if(monthIndex<12)
		{
			calendar = new GregorianCalendar(2016,monthIndex,01);
		}
		else
		{
			if(monthIndex==12)
			{
				monthIndex = 0;
			}
			else if(monthIndex==13)
			{
				monthIndex = 1;
			}
			else if(monthIndex==14)
			{
				monthIndex = 2;
			}
			
			calendar = new GregorianCalendar(2017,monthIndex,01);
		}
		return calendar;	
	}


}