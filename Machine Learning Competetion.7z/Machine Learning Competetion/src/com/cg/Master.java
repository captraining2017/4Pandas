package com.cg;

import java.util.Date;

public class Master {

	String date;
	long customeID;
	long txnAmount;
	String txnType;
	long totalAmount;
	long totalCreditAmt;
	
	public Master(String date, long customeID, long txnAmount, String txnType,
			long totalAmount,long totalCreditAmt) {
		super();
		this.date = date;
		this.customeID = customeID;
		this.txnAmount = txnAmount;
		this.txnType = txnType;
		this.totalAmount = totalAmount;
		this.totalCreditAmt = totalCreditAmt;
	}

	public String getDate() {
		return date;
	}

	public long getTotalCreditAmt() {
		return totalCreditAmt;
	}

	public void setTotalCreditAmt(long totalCreditAmt) {
		this.totalCreditAmt = totalCreditAmt;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public long getCustomeID() {
		return customeID;
	}

	public void setCustomeID(long customeID) {
		this.customeID = customeID;
	}

	public long getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(long txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(long totalAmount) {
		this.totalAmount = totalAmount;
	}

	@Override
	public String toString() {
		return "Master [date=" + date + ", customeID=" + customeID
				+ ", txnAmount=" + txnAmount + ", txnType=" + txnType
				+ ", totalAmount=" + totalAmount + ", totalCreditAmt="
				+ totalCreditAmt + "]";
	}
}